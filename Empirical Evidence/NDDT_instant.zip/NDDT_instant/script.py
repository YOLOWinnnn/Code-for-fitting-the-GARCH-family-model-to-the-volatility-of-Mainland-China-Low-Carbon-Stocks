import os

cmd = 'python GARCH.py'
os.system(cmd)
cmd = 'python RGARCH.py'
os.system(cmd)
cmd = 'python GARCH-MIDAS.py'
os.system(cmd)
cmd = 'python RGARCH-MIDAS.py'
os.system(cmd)
cmd = 'python GARCH-MIDAS+X.py'
os.system(cmd)
cmd = 'python RGARCH-MIDAS+X.py'
os.system(cmd)
cmd = 'python GARCH-MIDAS+RV+X.py'
os.system(cmd)
cmd = 'python RGARCH-MIDAS+RV+X.py'
os.system(cmd)
